//
//  MultiplayerView.swift
//  PCL-Mac
//
//  Created by YiZhiMCQiu on 2025/5/18.
//

import SwiftUI

struct MultiplayerView: View {
    var body: some View {
        VStack {
            Text("Multiplayer view")
        }
    }
}
