//
//  OthersView.swift
//  PCL-Mac
//
//  Created by YiZhiMCQiu on 2025/5/18.
//

import SwiftUI

struct OthersView: View {
    var body: some View {
        VStack {
            Text("Others view")
        }
    }
}
